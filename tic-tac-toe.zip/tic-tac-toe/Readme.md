This is simple tic tac toe played using input
